import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    ));

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        backgroundColor: Colors.grey[850],
        title: Text(
          'Id Card',
          style: TextStyle(
            letterSpacing: 3.0,
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Padding(
        padding: EdgeInsets.fromLTRB(30.0, 25.0, 30.0, 0.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: CircleAvatar(
                backgroundImage: AssetImage('assets/roni.jpg'),
                radius: 50.0,
              ),
            ),
            Divider(
              height: 50.0,
              color: Colors.amberAccent,
            ),
            Text(
              'Name:',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18.0,
                letterSpacing: 2.0,
              ),
            ),
            Text(
              'Roni Sarder',
              style: TextStyle(
                color: Colors.amberAccent[200],
                fontSize: 22.0,
                letterSpacing: 2.0,
              ),
            ),
            SizedBox(height: 15.0),
            Text(
              'Address:',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18.0,
                letterSpacing: 2.0,
              ),
            ),
            Text(
              'Mohammad Nagor,Gollamari\nPO: Jalma  Zip:9260\nKhulna, Bangladesh',
              style: TextStyle(
                color: Colors.amberAccent[200],
                fontSize: 18.0,
                letterSpacing: 1.0,
              ),
            ),
            SizedBox(height: 15.0),
            Container(
              child: Row(
                children: [
                  Icon(
                    Icons.phone,
                    color: Colors.grey[400],
                  ),
                  SizedBox(width: 15.0),
                  Text(
                    'Mobile:',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 18.0,
                      letterSpacing: 2.0,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              '01521307835',
              style: TextStyle(
                color: Colors.amberAccent[200],
                fontSize: 22.0,
                letterSpacing: 2.0,
              ),
            ),
            SizedBox(height: 15.0),
            Text(
              'Email me:',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18.0,
                letterSpacing: 2.0,
              ),
            ),
            Container(
              child: Row(
                children: [
                  Icon(
                    Icons.email,
                    color: Colors.grey[400],
                  ),
                  SizedBox(width: 10.0),
                  Text(
                    'cloudyrony@gmail.com',
                    style: TextStyle(
                      color: Colors.amberAccent[200],
                      fontSize: 18.0,
                      letterSpacing: 2.0,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 15.0),
            Text(
              'ID NO:',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 18.0,
                letterSpacing: 2.0,
              ),
            ),
            Container(
              child: Row(
                children: [
                  Icon(
                    Icons.account_box,
                    color: Colors.grey[400],
                  ),
                  SizedBox(width: 10.0),
                  Text(
                    '1506169695',
                    style: TextStyle(
                      color: Colors.amberAccent[200],
                      fontSize: 18.0,
                      letterSpacing: 2.0,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
